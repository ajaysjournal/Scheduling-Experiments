*Readme*
---------------------------------------------------
Requirements:

An envioronment with the following hardware 
Nvidia GPU
Nvidia Compiler
GCC Compiler

OR

A virtual enviornment with the given set
---------------------------------------------------

Execution:

1. Compile the program with the collowing command:
>>nvcc cuda.cu -o cuda

2. Generated output file can run using 
>>./cuda

This program will utilize the data file and display the time in the end. We compare this results with the seria code results for the same function in java.